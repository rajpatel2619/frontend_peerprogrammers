// src/pages/ForgotPassword.js
export default function ForgotPassword() {
    return <h2>Forgot Password Page (Coming Soon)</h2>;
  }
  