import React from 'react'

function StudentPublicProfile() {
  return (
    <div>StudentPublicProfile</div>
  )
}

export default StudentPublicProfile