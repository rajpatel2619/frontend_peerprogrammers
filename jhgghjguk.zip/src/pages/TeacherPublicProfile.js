import React from 'react'

function TeacherPublicProfile() {
  return (
    <div>TeacherPublicProfile</div>
  )
}

export default TeacherPublicProfile