import React from 'react'

function UserPublicProfile() {
  return (
    <div>UserPublicProfile</div>
  )
}

export default UserPublicProfile