
import ResetPasswordPage from "../components/ResetPassword";

// src/pages/ForgotPassword.js
export default function ChangePassword() {
    return (
      <>
      <ResetPasswordPage />
      </>
    );
  }
  