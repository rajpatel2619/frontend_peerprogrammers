import React from "react";

function IndividualFormTab() {
  return (
    <></>
    // <div className="bg-green-50 dark:bg-gray-700 p-4 rounded mt-4">
    //   <h2 className="text-lg font-semibold mb-2">Individual Details</h2>
    //   <input
    //     type="text"
    //     placeholder="Full Name"
    //     className="w-full mb-2 px-4 py-2 rounded border dark:bg-gray-600"
    //   />
    //   <input
    //     type="text"
    //     placeholder="LinkedIn Profile URL"
    //     className="w-full mb-2 px-4 py-2 rounded border dark:bg-gray-600"
    //   />
    // </div>
  );
}

export default IndividualFormTab;
