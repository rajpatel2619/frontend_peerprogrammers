import ForgotPasswordPage from "../components/ForgotPasswordPage";

// src/pages/ForgotPassword.js
export default function ForgotPassword() {
    return (
      <>
      <ForgotPasswordPage />
      </>
    );
  }
  