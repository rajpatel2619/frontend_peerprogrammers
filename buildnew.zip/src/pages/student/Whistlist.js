import React from 'react'

export default function Whistlist() {
  return (
    <div>Whistlist</div>
  )
}
